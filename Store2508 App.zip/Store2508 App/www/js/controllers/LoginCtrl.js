﻿app.controller('LoginCtrl', function ($scope, $ionicModal, $ionicPopover,$timeout) {

    $scope.test="This is Slider";
     

});